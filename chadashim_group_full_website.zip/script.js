
document.addEventListener("DOMContentLoaded", () => {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];

  document.querySelectorAll(".add-to-cart").forEach(button => {
    button.addEventListener("click", () => {
      const productId = button.dataset.id;
      const productName = button.dataset.name;
      const productPrice = parseFloat(button.dataset.price);

      const existingItem = cart.find(item => item.id === productId);
      if (existingItem) {
        existingItem.quantity++;
      } else {
        cart.push({ id: productId, name: productName, price: productPrice, quantity: 1 });
      }

      localStorage.setItem("cart", JSON.stringify(cart));
      alert(`${productName} added to cart.`);
    });
  });

  if (document.querySelector(".cart-items")) {
    const cartContainer = document.querySelector(".cart-items");
    cartContainer.innerHTML = "";
    cart.forEach((item, index) => {
      const div = document.createElement("div");
      div.innerHTML = `${item.name} (x${item.quantity}) - $${(item.price * item.quantity).toFixed(2)} <button data-index="${index}" class="remove">Remove</button>`;
      cartContainer.appendChild(div);
    });

    document.querySelectorAll(".remove").forEach(button => {
      button.addEventListener("click", () => {
        const index = button.dataset.index;
        cart.splice(index, 1);
        localStorage.setItem("cart", JSON.stringify(cart));
        location.reload();
      });
    });

    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    document.querySelector(".cart-total").textContent = `Total: $${total.toFixed(2)}`;
  }
});
